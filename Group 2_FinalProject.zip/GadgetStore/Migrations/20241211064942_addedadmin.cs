﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GadgetStore.Migrations
{
    /// <inheritdoc />
    public partial class addedadmin : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
